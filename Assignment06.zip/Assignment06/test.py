def DoMath(N1,2)
    Sum = N1 + N2
    Difference = N1 - N2
    Product = N1 * N2
    Quotient = N1 / N2
    return [Sum, Difference, Product, Quotient]

print(DoMath(4,3))
