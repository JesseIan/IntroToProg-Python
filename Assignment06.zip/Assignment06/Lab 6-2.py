def DoMath(N1,2)
    Sum = N1 + N2
    Difference = N1 - N2
    Product = N1 * N2
    Quotient = N1 / N2
    return [Sum, Difference, Product, Quotient]

1stAnswer = DoMath(3,4)
print("For Values", A1, "and", A2)
print("The Sum is:", 1stAnswer[0])
print("The Difference is:", 1stAnswer[1])
print("The Product is:", 1stAnswer[2])
print("The Quotient is:", 1stAnswer[3])
