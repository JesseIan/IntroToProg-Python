def DoMath(N1, N2):
    Sum = N1 + N2
    Difference = N1 - N2
    Product = N1 * N2
    Quotient = N1/N2
    print("For Values", N1, "and", N2)
    print("The Sum is:", Sum)
    print("The Difference is:", Difference)
    print("The Product is:", Product)
    print("The Quotient is:", Quotient)

DoMath(3,4)
