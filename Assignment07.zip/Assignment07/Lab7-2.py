# Input data
objFile = None #Handle
strUserInput = None # Holds user input

#process
def WriteProductUserInput(File):
    try:
        print("Type in a Product ID, Name, and Price you want to add to the file")
        print("(Enter 'Exit' to quite!)")
        while(True):
            strUserInput = input("Enter the ID, name, and price")
            if(strUserInput.lower() == "exit"): break
            else: File.write(strUserInput + "\n")
    except Exception as e:
            print("Error: ", + str(e))

def ReadAllFileData(File, Message="Contents of File"):
    try:
        print(Message)
        File.seek(0)
        print(File.read())
    except:
            print("Error")
    
try:
    objFile = open("Products.txt","r+")
    ReadAllFileData(objFile, "Here is the current data:")
    WirteProductUserInout(objFile)
    ReadAllFileData(objFile, "Here is the data that was saved:")
except FileNotFoundError as e:
    print("error: " + str(e))
except:
    print("Error")

finally:
    if(objFile != None): objFile.close()
