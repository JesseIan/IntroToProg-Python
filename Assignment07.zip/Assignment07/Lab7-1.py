# Input data
objFile = None #Handle
strUserInput = None # Holds user input

#process
def WriteProductUserInput(File):
    print("Type in a Product ID, Name, and Price you want to add to the file")
    print("(Enter 'Exit' to quite!)")
    while(True):
        strUserInput = input("Enter the ID, name, and price")
        if(strUserInput.lower() == "exit"): break
        else: File.write(strUserInput + "\n")

def ReadAllFileData(File, Message="Contents of File"):
    print(Message)
    File.seek(0)
    print(File.read())
    
objFile = open("Products.txt","r+")

ReadAllFileData(objFile, "Here is the current data:")

WirteProductUserInout(objFile)

ReadAllFileData(objFile, "Here is the data that was saved:")

objFile.close()
