# Assignment07
# Exception Handling
# Dev: Ian Beebe
# 8/25/2019

# A simple script for exception handling
# I will be creating an easy input for basic math that can easily cause error
try:
    num = int(input("Enter a number: "))
    num2 = int(input("Enter another number to divide by: "))
    ans = num/num2
# If the user inputs a non int they will get this 
except ValueError:
    print("Value is not an int")
# If the user inputs 0 they will get this error
except ZeroDivisionError:
    print("Zero cannot be used")
# If the user inputs a correctly divisble number it will print the answer
else:
    print("The answer is ", ans)


