# Assignment07
# Pickling
# Dev: Ian Beebe
# 8/25/2019

# Let the program find a file where there is "pickled" data
import pickle

# Get the data to store
def storeData():
    pickleList = {'pickle' : 'List', 'List Name' : 'PickleList',
              'amount' : 10, 'add' : 10}
    pickleList1 = {'pickle' : 'Another', 'List Name' : 'PickleList1',
                   'amount' : 15, 'add' : 15}
                   
    # The Database
    db = {}
    db['pickleList'] = List1
    db['pickleList1'] = List2

    #Now we store the data with the pickle.dump method
    objFile = open("Customers.dat", "ab")
    pickle.dump(lstCustomer, objFile)
    objFile.close()

# Read the data back with the same pickle.load method I found from the assignment
objFile = open("Customers.dat", "rb")
objFileData = pickle.load(objFile) #Note that load() only load one row of data.
objFile.close()

print(objFileData)
