# ---------------------------------------#
# Title: Assignment 05
# Dev: Jesse Ian
# Date: 08/12/2019
# ---------------------------------------#

# Open document and make it editable
lstTasks = []
dicList = {}
filToDo = open("ToDo.txt", "r")

# Reference document
for items in filToDo:
    print(filToDo.readlines()[0])
    dicList = {"Pay Bills":"high"}
    for task, prior in dicList.items():
        print("Task at hand ",task)
        print("Priority of task ",prior)
    continue

# End readable portion
filToDo.close()

#dictionary and references
taskReference = ["Task", "Priority"]
lstTasks.insert(0,taskReference)
lstTasks= [dicList]

#Let it think
select = None
while select !="0":

    print(
        '''
        Menu Options:
        
        Choose 1 - Exit Without Saving
        Choose 2 - to Add Item
        Choose 3 - to Remove Existing Item
        Choose 4 - to Save all tasks to the ToDo file
        '''
    )

# User to input what they want
    try:
        select = int(input("Please Make A Selection: "))
    except:
        print("Please Enter 1 - 4 from the list")
        select = int(input("Please Make A Selection: "))
    # Or exit without saving
    if select == "1":
        print("Exiting the programing without saving")

# Add task
    if select == "2":
        addTask = input("What task would you like added?: ")
        if addTask not in dicList:
# Lets user add task priority
            addPrior = input("What level of priority is this? High/Medium/Low")
            if (addPrior.lower() == "y"):
                dicList[addTask] = addPrior
            print(addTask,"has been added to the list!")
        else:
            print("That task is already on the list, give us another one")

# Delete task
    elif select == "3":
        addTask = input("Pick a task to remove, use full description of",dicList,"\n")
        if addTask in dicList:
            del dicList[addTask]
            print("The",addTask,"is gone")
        else:
            print(addTask,"was not removed due to error, try again")

    elif select == "4":
        strUserData = input("Press any key to save and exit: ")
# Opens file to write new info
        filToDo = open("ToDo.txt","w")
        print("You're now saving to ToDo.txt")
# Saves new data
        filToDo.write(lstTasks)

        break

filToDo.close()
