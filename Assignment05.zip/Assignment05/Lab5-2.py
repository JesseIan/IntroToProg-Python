#1 Creating the data dictionary
dicRow1 = {"ID":1,"Name":"Bob Smith","Email":"BSmith@Hotmail.com"}
dicRow2 = {"ID":2,"Name":"Sue Jones","Email":"SueJ@Yahoo.com"}
dicRow3 = {"ID":3,"Name":"Joe James","Email":"JoeJames@Gmail.com"}
lstTable = [dicRow1,dicRow2,dicRow3]
print(lstTable)

#2 Append
#3 Loop
while(True):
    intID = int(input("Enter an ID: "))
    strName = input("Enter a name: ")
    strEmail = input("Enter an Email: ")
    dicNewRow = {"ID":intID, "Name":strName, "Email":strEmail}
    lstTable.append(dicNewRow)
    if(input("Type 'exit' to end ").lower() == "exit"):break

#4 Ask the suer if they want to save when exiting above loop
strSaveToFile = input("Would you like to save your data file?(y/n): ")

#5
if(strSaveToFile.lower() == 'y'):
    objF = open("Lab05Data.txt",'a')
    objF.write(str(lstTable))
    objF.close()
    print("The following data was saved to file:\n\r", lstTable)
else:
    print("Data not saved")

