#1 List to hold following data
lstRow0 = ["ID", "Name", "Email"]
lstRow1 = [1,"Bob Smith", "BSmith@Hotmail.com"]
lstRow2 = [2,"Sue Jones", "SueJ@Yahoo.com"]
lstRow3 = [3,"Joe James", "JoeJames@Gmail.com"]
lstTable = [lstRow0, lstRow1, lstRow2, lstRow3]

#2 Append new rows per the user 
#3 Loop so user can enter more rows
while(True):
    intID = str(input("Enter an ID: "))
    strName = input("Enter a name: ")
    strEmail = input("Enter an Email: ")
    lstNewRow = [intID, strName, strEmail]
    lstTable.append(lstNewRow)
    if(input("Type 'exit' to end ").lower() == "exit"):break

#4 Ask the suer if they want to save when exiting above loop
strSaveToFile = input("Would you like to save your data file?(y/n): ")

#5
if(strSaveToFile.lower() == 'y'):
    objF = open("Lab05Data.txt",'a')
    objF.write(str(lstTable))
    objF.close()
    print("The following data was saved to file:\n\r", lstTable)
else:
    print("Data not saved")
