#---- Make the class ---
class Person(object):
    """ Base Class for Personal data """
    #----------------------------------#
    # Desc: Holds Personal Data
    # Dev: Jesse Ian
    # Date: 9/1/2019
    # ChangeLog:
    #---------------------------------#

    #--Fields--
    FirstName = ""
    LastName = ""

    #--Constructor--
        # Attributes
    #--Properties--

    #--Methods--
    def ToString(self):
        return self.FirstName + "," + self.LastName

#--End of class--

#--- Use the class ---
# by making an object
objP1 = Person()
objP1.FirstName = "Bob"
objP1.LastName = "Smith"

objP2 = Person()
objP2.FirstName = "Sue"
objP2.LastName = "Jones"

print(objP1.ToString())
print("-------------")
print(objP2.ToString())
