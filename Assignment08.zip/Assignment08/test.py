class Employee(Person):
    """ Class for Employee data """
    #-------------------------------------#
    #Desc:  Test
    #Dev:    
    #Date:  
    #ChangeLog:(When,Who,What)
    #-------------------------------------#   
    #--Fields--
    #--Constructor--
    def __init__(self, Id = ""):
        #Attributes
        self.__Id = Id

    #--Properties--      
    # Id    
    @property #getter(accessor) 
    def Id(self):
        return self.__Id
    
    @Id.setter #(mutator)
    def Id(self, Value):
        self.__Id = Value
    
    #--Methods--
    def ToString(self): # This overrides the original method (it's polymorphic)
        """Explictly returns field data"""
        strData = super().ToString()
        return str(self.Id) + ',' + strData
    
    def __str__(self): # This overrides the original method as well
        """Implictly returns field data"""
        strData = super().__str__()
        return str(self.Id) + ',' + strData   
#--End of Class --        

# --- Use the class ----
# by making an object!
objE1 = Employee()
objE1.Id = 1
objE1.FirstName = "Earl"
print(objE1.ToString())
print(objE1)
