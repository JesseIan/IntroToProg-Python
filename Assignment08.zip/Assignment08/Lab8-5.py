#---- Make the class ---
class Person(object):
    """ Base Class for Personal data """
    #----------------------------------#
    # Desc: Holds Personal Data
    # Dev: Jesse Ian
    # Date: 9/1/2019
    # ChangeLog:
    #---------------------------------#

    #--Fields--
    FirstName = ""
    LastName = ""

    #--Constructor--
    def __init__(self, FirstName = "", LastName = ""):
        # Attributes
        self.FirstName = FirstName
        self.LastName = LastName
    #--Properties--
    #FirstName
    @property # (getter/accessor)
    def FirstName(self):
        return self.__FirstName

    @FirstName.setter # (setter/mutator)
    def FirstName(self, Value):
        self.__FirstName = Value

    #LastName
    @property
    def LastName(self):
        return self.__LastName

    @LastName.setter # (setter/mutator)
    def LastName(self, Value):
        self.__LastName = Value


    #--Methods--
    def ToString(self):
        return self.FirstName + "," + self.LastName

    def __str__(self):
        return self.ToString()

#--End of class--

class Customer(Person):
    #--Fields--
    #__ID = 0
    #--Constructor--
    def __init__(self, ID, FirstName, LastName):
        #Attributes
        self.__ID = ID
        super(Customer, self).__init__(FirstName,LastName)

    #--Properties--
    # ID    

    @property #getter(accessor) 

    def ID(self):

        return self.__ID

    

    @Id.setter #(mutator)

    def ID(self, Value):

        self.__ID = Value



    #--Methods
    def ToString(self)
        strData == super().ToString()
        return str(self.Id) + "," + strData

    def __str__(self):
        strData = super()__str__()
        return str(self.Id) + "," + strData

#-- End of Class--

# --- Use the class ----
# By making an object
objE1 = Employee(1)
objE1.Id = 1
objE1.FirstName = "Earl"
print(objE1.ToString())
print(objE1)
