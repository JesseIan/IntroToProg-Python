#---- Make the class ---
class Person(object):
    """ Base Class for Personal data """
    #----------------------------------#
    # Desc: Holds Personal Data
    # Dev: Jesse Ian
    # Date: 9/1/2019
    # ChangeLog:
    #---------------------------------#

    #--Fields--
    FirstName = ""
    LastName = ""

    #--Constructor--
    def __init__(self, FirstName, LastName)
        # Attributes
        self.FirstName = FirstName
        self.LastName = LastName
    #--Properties--

    #--Methods--
    def ToString(self):
        return self.FirstName + "," + self.LastName

#--End of class--

#--- Use the class ---
# by making an object
objP1 = Person("Bob","Smith")
# objP1.FirstName = "Bob"
# objP1.LastName = "Smith"

objP2 = Person()
objP2.FirstName = "Sue"
objP2.LastName = "Jones"

print(objP1.ToString())
print("-------------")
print(objP2.ToString())
